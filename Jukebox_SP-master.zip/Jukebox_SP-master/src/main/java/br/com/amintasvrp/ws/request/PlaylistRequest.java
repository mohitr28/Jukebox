package br.com.amintasvrp.ws.request;

public class PlaylistRequest {
	
	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
