package br.com.amintasvrp.ws.request;

public class MusicaPlaylistRequest {
	
	private String musica;
	private String playlist;
	
	public String getMusica() {
		return musica;
	}
	public String getPlaylist() {
		return playlist;
	}
	public void setMusica(String musica) {
		this.musica = musica;
	}
	public void setPlaylist(String playlist) {
		this.playlist = playlist;
	}
	
	

}
